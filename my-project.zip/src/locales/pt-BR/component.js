export default {
  'component.tagSelect.expand': 'Expandir',
  'component.tagSelect.collapse': 'Colapso',
  'component.tagSelect.all': 'Todas',
};
