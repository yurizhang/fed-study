export default {
  'app.exception.back': '返回首頁',
  'app.exception.description.403': '抱歉，妳無權訪問該頁面',
  'app.exception.description.404': '抱歉，妳訪問的頁面不存在',
  'app.exception.description.500': '抱歉，服務器出錯了',
};
